# B1–B2 SPI接入记录

日期：2026-10-20。协议基线为 [SPI v0.6](b1_b2_spi_protocol.md)。本记录是内部实现及验收说明，不向对外Word堆叠驱动细节。

## 1. 本轮范围和任务边界

已接入V2/B1源码，但未烧录、未推送、未连接网络/串口/ST-Link。原PC/RK线上字段、B1真实电源、V2电源模拟和第一颗MATS假FAIL的构建差异保持不变。

| 模块 | 职责 | 不负责 |
|---|---|---|
| `App/tasks/b2/b2_task.c` | 独立4KiB任务：取SPI事务、解析、重试去重、提交业务、发布应答、3秒离线诊断 | RK串口/算法/Seq；温控执行 |
| `App/protocol/b2/` | 纯C帧/TLV校验、CS状态机、应答编码 | GPIO、RTOS、网络 |
| `App/tasks/b2/b2_service.c` | 单槽请求/应答队列、有效编号/镜像模式缓存、调用网络和整轮接口 | SPI寄存器、RK队列 |
| `HAL_Drv/b2_spi.c` | 实际SPI从机、DMA、NSS上升沿事务边界、固定长度队列 | PC/RK业务 |
| `HAL_Drv/network_config.c` | 在lwIP线程执行运行时IPv4更新 | FRU持久化、TCP应用协议 |
| `App/tasks/rk/` | 原有独立RK任务 | 任何B2收发或心跳 |
| `App/protocol/common/crc.[ch]` | 共用无状态Modbus CRC16函数 | 任何一方帧、Seq或状态机 |

B2与RK是并列任务，不在RK任务中增加SPI轮询。B2也不增加一个独立心跳任务：B2主机定期发0004，B1从机被动应答。

业务状态只有一个写入者：B2任务经队列提交，TCP任务通过 `b2_service_poll()` 顺序处理，避免SPI任务与PC命令同时改整轮/灯态或关闭socket；网络底层再通过 `tcpip_try_callback()`进入lwIP线程。此安排不把B2报文交给PC帧解析器，也不复用RK协议业务。

## 2. 事务与异常处理

- 一个CS低电平事务只接受一个完整帧；不跨CS拼接、不在坏事务中扫描5A重新同步。短帧、尾部多字节、CRC或TLV结构损坏不响应。
- 命令可识别但参数不合法时回状态1；旧0001/0002/0003回3。不认识但结构合法的TLV跳过；已知字段重复、长度错误及重复镜像整包拒绝。
- 应答回显本次B2 Seq。仅保存上一份请求/响应：相同Seq且字节相同直接复用响应，不重复执行业务；相同Seq但内容不同拒绝，保留原缓存。
- ISR只收CS快照入4槽队列。SPI DMA收发缓冲放AXI SRAM的`.b2_dma`，NOLOAD区显式初始化；DMA1 Stream3/4不占UART的Stream0～2。
- 应答候选只在CS上升沿换入TX；首次读取可能为FF，主机须继续按协议轮询。一次读应答必须保持CS低：先13字节头，再读剩余字节。
- RX越界、DMA/SPI错误或队列满有只读计数。停止DMA有固定上限，异常时不重用仍运行的DMA缓冲。
- 100ms是主机单次观察窗口，不承诺所有业务拥塞时均在100ms内完成。已提交网络变更不因主机超时伪称未执行；重试依靠相同Seq缓存确认。下一轮周期交换使用新Seq。
- 3秒未收到结构完整且命令可识别的帧标记离线，不自动清IP、不推断常温、不改PASS，也不操作加热。

当前缓存不是跨复位去重日志；B2重启后若重复使用上一Seq却携带新内容，会先收到参数错误，后续新Seq才可执行。不增加Flash写入或无限历史表。

## 3. IP、siteId与灯态

| 项目 | 本轮实现 |
|---|---|
| testerId | B2的3003通知1～21，0仅用于尚未配置的响应 |
| siteId | B1读取PB5:PB4:PB3原始槽位码加1；V2构建项`B2_TEST_SITE_ID`默认1，范围1～8 |
| 地址 | `192.168.210.(10*testerId+siteId)`，掩码255.255.255.0，网关0.0.0.0，端口8888 |
| 切换时机 | 每次合法0004检查当前槽位；tester或slot不同才重配；slot不是B2请求中的可写字段 |
| busy | 改IP且已有被接受的PC连接、测试/电源切换或OTA下载/待提交在途，整包回2，不改灯或缓存 |
| 同IP | 无需网络重配，可单独更新温控显示模式 |
| 复位 | 配置只在RAM；首次通知前维持本地测试IP，FRU布局和记录不改 |
| PC结果siteId | 正式配置生效后使用对应槽位字符串；未配置时保留FRU本地测试标签 |
| 开始整轮0106 | 按已知镜像模式显示：常温双通道闪、高温FAIL通道闪、未知灭 |
| 局部模式更新 | 只更新本包列出的镜像；轮外缓存、轮内更新显示，不控制加热 |
| 收尾0107 | 按errorchip形成最终PASS/FAIL；后续模式通知只缓存，不覆盖结果 |

“PC无连接”以TCP任务已接受的连接为界；IP切换前仍须由现场流程停止连接尝试，不能将该门禁当成多主机网络仲裁。PC首次发现B2、正式上线前多板重名IP的隔离、B2真实八槽片选和贴装仍需系统联调，不能把默认`.201`作为多板同时接入的产线地址。

## 4. 两板接口与最小主机

- B1：SPI2，PB12 NSS / PB13 SCK / PB14 MISO / PB15 MOSI；AD7124仍SPI4。
- 网关V2：SPI3，PA15 NSS / PB3 SCK / PB4 MISO / PB5 MOSI；不占AD7124的SPI2或结果灯的PC10～12。
- 两者Mode0、8位MSB、硬件NSS低有效。新B2任务只进入正常业务镜像，不进入旧器件Mock/Flash/AD波形镜像。
- 第二块阿波罗V2使用 `tools/b2_spi_master/`，裸机USART1+SPI3主机，HSI64MHz、SPI1MHz。只编译不自动烧录，起始地址0x08000000，禁止覆盖网关的完整OTA Boot。
- 接线、命令和验收顺序见[裸机主机README](../tools/b2_spi_master/README.md)。

## 5. 已执行的验证

| 验证 | 结果 |
|---|---|
| V2/B1实际C：B2协议、CS状态机、任务重试、业务队列、裸机编解码 | QEMU通过；含黄金帧、CRC损坏、1024字节载荷、16/17 TLV、重复字段/镜像、Seq冲突/回绕、busy/失败及部分模式 |
| PC实际C：V2模拟、模拟+MATS、整轮；B1真实门禁、整轮及电源编排 | 通过；新增未知模式灭灯、局部更新、0107结果保持及B2站点号，V2 MATS80组隔离仍通过 |
| RK实际C V2/B1 | 通过；共用CRC移位不改线格式/算法匹配 |
| V2 UART/IDD实际C、两板普通构建 | 通过；保留原UART恢复、RK边界及IDD统计窗口规则 |
| PC合同、架构边界/纯接口头、B1完整check | 通过；边界新增“B2不依赖RK，独立创建任务” |
| V2 OTA Debug（电源模拟+MATS）A1/A2 | 267924字节，2065处地址修正；正反修正与独立链接逐字节一致 |
| B1 OTA Debug真实A1/A2 | 261188字节，1984处地址修正；正反修正逐字节一致 |
| DMA布局 | 两板链接map中`.b2_dma`均位于0x24020000，大小0x840；不是DTCM |
| 第二块裸机主机 | ELF/HEX/BIN构建通过，text24469、data96、bss11208字节 |

OTA回归版本0.1.0仅作离线地址修正测试，不是正式发布包或已安装版本。

复跑入口：

```powershell
powershell -ExecutionPolicy Bypass -File tools/dev.ps1 b2-protocol-test
python -B -X utf8 tests/verify_b2_protocol_c.py --app-root ../b1
powershell -ExecutionPolicy Bypass -File tools/b2_spi_master/build.ps1
```

## 6. 待实板验收

1. 两块V2接线，先测query/CRC/Seq，再测testerId切IP及部分镜像模式。
2. 逻辑分析仪核验1MHz/Mode0、CS间隔、13字节读头与续读、首次FF轮询、MISO未选中高阻和断帧恢复。
3. 测PC连接/测试/OTA在途改IP的busy，以及断开后新Seq成功；核验真正netif切换、ARP、socket重连。
4. 测长串口日志/网络负载下DMA队列及任务栈/RTOS堆余量，不把离线吞吐推断为实板吞吐。
5. B1八槽贴装、CS对应、真实灯色与多从机共享总线待板；B2真实固件及PC侧配置流程待双方联调。

不修改加热权、PC或RK协议字段；不把本轮离线结果写成真实SPI/网络/灯光验收。
